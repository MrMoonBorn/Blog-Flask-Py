import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
# login işlemini sağlıyor

app = Flask(__name__)
#############################################################################
############ CONFIGURATIONS (CAN BE SEPARATE CONFIG.PY FILE) ###############
###########################################################################

# Remember you need to set your environment variables at the command line
# when you deploy this to a real website.
# export SECRET_KEY=mysecret
# set SECRET_KEY=mysecret
app.config['SECRET_KEY'] = 'mysecret'

############################
### DATABASE SETUP ##########
########################
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///'+os.path.join(basedir,'data.sqlite')
# database bağlıyor
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
Migrate(app,db)
# running site testte cmdye flask db migrate -m yaz çalıştır sonrada flask db upgrade yaz çalıştır

# mekanizmayı çalıştıracağın zaman flask db komutlarını çalıştırmalıyız bunun için:
# aktif env'ine> flask db init komutunu çalıştır sonrası
# flask db migrate -m komutunu çalıştır
# son olarak> flask db upgrade

#########################
# LOGIN CONFIGS
login_manager = LoginManager()

# We can now pass in our app to the login manager()
login_manager.init_app(app)
# Tell users what view to go to when they need to login.()
login_manager.login_view = 'users.login'




##################################################

# bütün __init__leri toplayıp app.py ye koyoyor main __init__denilebilir #

from MyBlog.core.views import core
from MyBlog.error_page.handlers import error_pages
from MyBlog.blog_posts.views import blog_posts
from MyBlog.users.views import users

app.register_blueprint(core)
app.register_blueprint(users)
app.register_blueprint(error_pages)
app.register_blueprint(blog_posts)
